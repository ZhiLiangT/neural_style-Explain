from chainer.links.caffe import caffe_function


# for backward compatibility
CaffeFunction = caffe_function.CaffeFunction
