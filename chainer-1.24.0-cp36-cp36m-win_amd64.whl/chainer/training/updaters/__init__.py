from chainer.training.updaters import multiprocess_parallel_updater  # NOQA

from chainer.training.updaters.multiprocess_parallel_updater import MultiprocessParallelUpdater  # NOQA
