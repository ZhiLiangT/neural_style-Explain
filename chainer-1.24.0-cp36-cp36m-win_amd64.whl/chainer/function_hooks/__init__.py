from chainer.function_hooks import cuda_profile  # NOQA
from chainer.function_hooks import debug_print  # NOQA
from chainer.function_hooks import timer  # NOQA


# import class and function
from chainer.function_hooks.cuda_profile import CUDAProfileHook  # NOQA
from chainer.function_hooks.debug_print import PrintHook  # NOQA
from chainer.function_hooks.timer import TimerHook  # NOQA
